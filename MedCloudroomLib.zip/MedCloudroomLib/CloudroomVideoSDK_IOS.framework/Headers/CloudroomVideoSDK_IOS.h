//
//  CloudroomVideoSDK_IOS.h
//  CloudroomVideoSDK_IOS
//
//  Created by lake on 2017/9/26.
//  Copyright © 2017年 lake. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CloudroomVideoSDK_IOS.
FOUNDATION_EXPORT double CloudroomVideoSDK_IOSVersionNumber;

//! Project version string for CloudroomVideoSDK_IOS.
FOUNDATION_EXPORT const unsigned char CloudroomVideoSDK_IOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CloudroomVideoSDK_IOS/PublicHeader.h>

#import <CloudroomVideoSDK_IOS/CloudroomVideoSDK.h>
#import <CloudroomVideoSDK_IOS/CloudroomVideoSDK_Def.h>
#import <CloudroomVideoSDK_IOS/CloudroomVideoMgr.h>
#import <CloudroomVideoSDK_IOS/CloudroomVideoMeeting.h>
#import <CloudroomVideoSDK_IOS/CloudroomQueue.h>
#import <CloudroomVideoSDK_IOS/CloudroomHttpFileMgr.h>
#import <CloudroomVideoSDK_IOS/CloudroomCommonType.h>
