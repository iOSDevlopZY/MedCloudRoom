//
//  CreatingRoomPlayerController.h
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/2/21.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^RoomIDBlock)(int roomID);
typedef void (^PopUpClickBlock)(int index);

@interface CreatingRoomPlayerController : UIViewController
/*是否消失*/
@property(nonatomic,assign)BOOL isDismiss;

@property (nonatomic,copy) RoomIDBlock callbackBlock;
@property (nonatomic,copy) PopUpClickBlock clickBlock;

/*创建房间的方法*/
-(void)CreateCloudRoomWithRoomID:(RoomIDBlock) block;
/*加入房间的方法*/
-(void)StartCloudRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo;
/*监听下拉菜单点击*/
-(void)listenPopupClick:(PopUpClickBlock) block withItemTitleArr:(NSArray *)titleArr logoArr:(NSArray *)logoArr;
/*患者病例/患者报告点击事件*/
-(void)checkPatientInfoOnWeb:(int)index withURL:(NSString*)url;
/*主动调用离开房间*/
-(void)leaveRoomWithError:(NSString *)errMsg;
@end

NS_ASSUME_NONNULL_END
