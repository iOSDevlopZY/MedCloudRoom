//
//  CameraViewController.m
//  iOSCameraViewWithDrawing
//
//  Created by zhangyi on 2020/7/17.
//  Copyright © 2020 medcare. All rights reserved.
//

#import "STCameraViewController.h"
#import <Photos/Photos.h>
#import <AVFoundation/AVFoundation.h>

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
@interface STCameraViewController () <AVCapturePhotoCaptureDelegate>

// 自定义相机（AVFoundation）
@property (nonatomic, strong) AVCaptureSession *session;                 // 会话
@property (nonatomic, strong) AVCaptureDevice *device;                   // 设备
@property (nonatomic, strong) AVCaptureDeviceInput *input;               // 设备输入
@property (nonatomic, strong) AVCapturePhotoOutput *output;              // 设备输出
@property (nonatomic, strong) AVCaptureConnection *connection;           // 连接
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *preViewLayer;  // 预览图层
@property (nonatomic, strong) AVCapturePhotoSettings *outputSettings;    // 拍照设置

// 界面
@property (nonatomic, strong) UIView *topView;                           // 顶部视图
@property (nonatomic, strong) UIView *middleView;                        // 中部视图
@property (nonatomic, strong) UIView *bottomView;                        // 底部视图
@property (nonatomic, strong) UIImageView *tongueView;                   // 覆盖视图

@property (nonatomic, strong) UIButton *backButton;                      // 返回按钮
@property (nonatomic, strong) UIButton *cameraButton;                    // 拍照按钮
@property (nonatomic, strong) UIButton *switchCameraButton;              // 切换摄像头按钮

@end

@implementation STCameraViewController

#pragma mark - 生存周期
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [_session startRunning];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self setCustomCamera];
    [self setupUI];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [_session stopRunning];
}

#pragma mark - 设置UI
- (void)setupUI{
    [self setMiddelViewUI];
    [self setTopViewUI];
    [self setBottomViewUI];
}

- (void)setTopViewUI{
    UIImage *backImg = [UIImage imageNamed:@"back"];
    UIImage *switchImg = [UIImage imageNamed:@"switchCamera"];
    _topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight*0.1)];
    _topView.backgroundColor = [UIColor blackColor];
    _backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, backImg.size.width/2, backImg.size.height/2 )];
    [_backButton setCenter:CGPointMake(kScreenWidth * 0.05, _topView.frame.size.height/2)];
    [_backButton setImage:backImg forState:UIControlStateNormal];
    [_backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    _switchCameraButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, switchImg.size.width/2, switchImg.size.height/2)];
    [_switchCameraButton setCenter:CGPointMake(kScreenWidth * 0.95 - switchImg.size.width/4, _topView.frame.size.height/2)];
    [_switchCameraButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [_switchCameraButton setImage:switchImg forState:UIControlStateNormal];
    [_switchCameraButton addTarget:self action:@selector(swapFrontAndBackCameras) forControlEvents:UIControlEventTouchUpInside];
    
    [_topView addSubview:_backButton];
    [_topView addSubview:_switchCameraButton];
    [_middleView addSubview:_topView];
}

- (void)setMiddelViewUI{
    _middleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    _middleView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_middleView];
    _preViewLayer.frame = _middleView.bounds;
    [_middleView.layer addSublayer:_preViewLayer];
    
    _tongueView = [[UIImageView alloc]initWithFrame:CGRectMake(-1, kScreenHeight*0.1, kScreenWidth + 2, kScreenHeight*0.75)];
    _tongueView.image = [UIImage imageNamed:@"tongue"];
    [_middleView addSubview:_tongueView];
    [_middleView bringSubviewToFront:_tongueView];
}

- (void)setBottomViewUI{
    _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight*0.85, kScreenWidth, kScreenHeight*0.15)];
    _bottomView.backgroundColor = [UIColor blackColor];
    _cameraButton = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth *0.4,(_bottomView.frame.size.height - kScreenWidth*0.2) * 0.5, kScreenWidth*0.2, kScreenWidth*0.2)];
    [_cameraButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [_cameraButton setImage:[UIImage imageNamed:@"takePhoto"] forState:UIControlStateNormal];
    [_cameraButton addTarget:self action:@selector(takePhoto) forControlEvents:UIControlEventTouchUpInside];
    [_bottomView addSubview:_cameraButton];
    [_middleView addSubview:_bottomView];
}

#pragma mark - 设置自定义相机
- (void)setCustomCamera{
    _session = [[AVCaptureSession alloc]init];
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];

    NSError *error = nil;
    _input = [[AVCaptureDeviceInput alloc] initWithDevice:_device error:&error];
    if (error) {
        [self showAlertMsg:@"创建视频输入设备失败"];
        return;
    }
    
    AVCapturePhotoOutput *output = [[AVCapturePhotoOutput alloc] init];
    _output = output;
    NSDictionary *setDic = @{AVVideoCodecKey:AVVideoCodecJPEG};
    _outputSettings = [AVCapturePhotoSettings photoSettingsWithFormat:setDic];
    
    [_output setPhotoSettingsForSceneMonitoring:_outputSettings];
   
    if ([_session canSetSessionPreset:AVCaptureSessionPreset1280x720]) {
        [_session setSessionPreset:AVCaptureSessionPreset1280x720];
    }
        
    if ([_session canAddInput:_input]) {
        [_session addInput:_input];
    }else {
        [self showAlertMsg:@"添加输入设备失败"];
        return;
    }
    if ([_session canAddOutput:output]) {
           [_session addOutput:output];
    }else {
        [self showAlertMsg:@"添加输出设备失败"];
        return;
    }
       
    AVCaptureVideoPreviewLayer *layer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    layer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _preViewLayer = layer;
}

#pragma mark - 辅助函数
- (void)showAlertMsg:(NSString*)msg{
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:msg preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil];
    [ac addAction:okAction];
    [self presentViewController:ac animated:YES completion:nil];
}

#pragma mark - 离开相机
- (void)back{
    if(self.picBlock)
        self.picBlock(@"");
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 拍照
- (void)takePhoto{
    _connection = [_output connectionWithMediaType:AVMediaTypeVideo];
    AVCapturePhotoSettings *settings = [[AVCapturePhotoSettings alloc]init];
    [_output capturePhotoWithSettings:settings delegate:self];
}

# pragma mark - AVCapturePhotoCaptureDelegate
- (void)captureOutput:(AVCapturePhotoOutput *)output didFinishProcessingPhotoSampleBuffer:(CMSampleBufferRef)photoSampleBuffer previewPhotoSampleBuffer:(CMSampleBufferRef)previewPhotoSampleBuffer resolvedSettings:(AVCaptureResolvedPhotoSettings *)resolvedSettings bracketSettings:(AVCaptureBracketedStillImageSettings *)bracketSettings error:(NSError *)error{
    // JPG格式
    NSData *data = [AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:photoSampleBuffer previewPhotoSampleBuffer:previewPhotoSampleBuffer];
    NSString *cachePath = [self getCachePath];
    NSString *fileName = [NSString stringWithFormat:@"%@.jpg",[self getCurrentTimes]];
    NSString *FileName=[cachePath stringByAppendingPathComponent:fileName];
    [data writeToFile:FileName atomically:YES];
    if(self.picBlock)
        self.picBlock(FileName);
    // 退出界面
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 获取Cache文件夹路径
- (NSString *)getCachePath
{
    NSArray *filePaths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    return [filePaths objectAtIndex:0];
}

#pragma mark -
- (NSString *)getCurrentTimes {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置想要的格式，hh与HH的区别:分别表示12小时制,24小时制
    [formatter setDateFormat:@"YYYYMMddHHmmss"];
    NSDate *dateNow = [NSDate date];
    //把NSDate按formatter格式转成NSString
    NSString *currentTime = [formatter stringFromDate:dateNow];
    return currentTime;
}

#pragma mark - 获取相机位置
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition)position{
    AVCaptureDeviceDiscoverySession *devices = [AVCaptureDeviceDiscoverySession discoverySessionWithDeviceTypes:@[AVCaptureDeviceTypeBuiltInWideAngleCamera] mediaType:AVMediaTypeVideo position:position];
    
    NSArray *devicesAll = devices.devices;
    for (AVCaptureDevice *device in devicesAll) {
        if ([device position] == position) {
            return device;
        }
    }
    return nil;
}

# pragma mark - 切换前后相机
- (void)swapFrontAndBackCameras {
    NSArray *inputs = _session.inputs;
    for ( AVCaptureDeviceInput *input in inputs ) {
        AVCaptureDevice *device = input.device;
        if ( [device hasMediaType:AVMediaTypeVideo] ) {
            AVCaptureDevicePosition position = device.position;
            AVCaptureDevice *newCamera = nil;
            AVCaptureDeviceInput *newInput = nil;
 
            if (position == AVCaptureDevicePositionFront)
                newCamera = [self cameraWithPosition:AVCaptureDevicePositionBack];
            else
                newCamera = [self cameraWithPosition:AVCaptureDevicePositionFront];
            newInput = [AVCaptureDeviceInput deviceInputWithDevice:newCamera error:nil];
 
            // 开始切换
            [_session beginConfiguration];
 
            [_session removeInput:input];
            [_session addInput:newInput];
 
            // 结束切换
            [_session commitConfiguration];
            break;
        }
    }
}

#pragma mark - 图片路径回调
- (void)getSavePicPathBlock:(picPathBlock) block
{
    self.picBlock = block;
}

#pragma mark - 全面屏适配
-(void)viewSafeAreaInsetsDidChange
{
    [super viewSafeAreaInsetsDidChange];
    // 如果是刘海屏
    if([self isNotchScreen])
    {
        UIImage *switchImg = [UIImage imageNamed:@"switchCamera"];
        _topView.frame = CGRectMake(0, 0, kScreenWidth, kScreenHeight*0.1 + 44);
        [_backButton setCenter:CGPointMake(kScreenWidth * 0.05, _topView.frame.size.height/2)];
        [_switchCameraButton setCenter:CGPointMake(kScreenWidth * 0.95 - switchImg.size.width/4, _topView.frame.size.height/2)];
        _tongueView.frame = CGRectMake(-1, kScreenHeight*0.1 + 44, kScreenWidth + 2, kScreenHeight*0.75 - 44);
        
    }
}

#pragma mark - 判断是否为刘海屏
- (BOOL)isNotchScreen {
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        return NO;
    }
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    NSInteger notchValue = size.width / size.height * 100;
    
    if (216 == notchValue || 46 == notchValue) {
        return YES;
    }
    return NO;
}
@end
