//
//  PlayerController.m
//  MedCloudroomLib
//
//  Created by pg on 2019/11/11.
//  Copyright © 2019年 美迪康yh. All rights reserved.
//

#import "PlayerController.h"
//#import <CloudroomVideoSDK_IOS/CloudroomVideoSDK_IOS.h>
#import "CustomCameraView.h"
#import "SDKUtil.h"
#import "HUDUtil.h"
#import "Masonry.h"
#import "MyCell.h"
#import "MeetingHelper.h"
#import "ELCVFlowLayout.h"

#define WeakSelf __weak typeof(self) weakSelf = self;
#define UIColorFromRGBA(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:a]

static NSString *reuseIdentifier = @"MyCell";

@interface PlayerController ()<CloudroomVideoMeetingCallBack, CloudroomVideoMgrCallBack,UICollectionViewDataSource,UICollectionViewDelegate,UIScrollViewDelegate,UICollectionViewDelegateFlowLayout>

@property (nonatomic,assign)CGFloat Screen_width;
@property (nonatomic,assign)CGFloat Screen_height;
@property (nonatomic,strong)UILabel *remindLabel;
@property (nonatomic,assign)float lastVideoCollectionViewOffsetYPortitNum;
@property (nonatomic,assign)float lastVideoCollectionViewOffsetYLandScapeNum;
@property (nonatomic,assign)BOOL isLandScape;

@property (nonatomic,strong)CustomCameraView *selfCameraView;
@property (nonatomic,strong)CustomCameraView *cusCameraView;
@property (nonatomic, strong)CLShareView *shareView; /**< 屏幕共享 */

@property (nonatomic,strong)UIPageControl *PageControl;

@property (nonatomic,strong)UIScrollView *MainScrollView;
@property (nonatomic,strong)UIView *MainVideoView;
@property (nonatomic,strong)UIView *InfoView;
@property (nonatomic,strong)UIView *TopView;  // 功能栏

@property (nonatomic, strong) NSMutableArray<UsrVideoId *> *members; /**< 房间成员 */
// ZY修改，增加一个内存记录集合
@property (nonatomic, strong) NSMutableArray<UsrVideoId *> *closeVideoMembers; /**< 房间关闭视频的成员(不删除)*/
@property (nonatomic, copy) NSArray<UsrVideoInfo *> *cameraArray; /**< 摄像头集合 */
@property (nonatomic, assign) NSInteger curCameraIndex; /**< 当前摄像头索引 */

@property (nonatomic, copy) NSString *m_nickname; /**< 昵称 */
@property (nonatomic, copy) NSString *m_Userid; /**< 用户id */

@property (nonatomic, copy) NSString *m_CreateUserid; /*创建房间的用户ID*/
@property (nonatomic, copy) NSString *m_CreateUserNickName; /*创建房间的用户昵称*/

@property (nonatomic, copy) NSString *titleStr;

@property (nonatomic, strong) MeetInfo *meetInfo;
@property (nonatomic, assign) BOOL isCreatingMeeting;  //添加是否创建房间标志
@property (nonatomic, strong) MeetInfo *createMeetInfo;//创建房间的信息

@property(nonatomic,strong)UICollectionView *VideoListView;  // 视频列表页

@property(nonatomic,strong)UIButton *EndButton;  // 退出按钮
@property(nonatomic,strong)UIButton *SoundButton;  // 外放按钮
@property(nonatomic,strong)UILabel *TitleLabel;  // 标题按钮
@property(nonatomic,strong)UIButton *MicButton;  // 麦克按钮
@property(nonatomic,strong)UIButton *CameraButton; // 摄像头按钮

@property (nonatomic, copy) NSString *curMainVideo; /**< 当前选中到大屏的用户ID */
@property (nonatomic, assign) short curMainVideoID; /**< 当前选中到大屏的videoID */

@property (nonatomic, copy) NSString *prevMainVideo; /**< 当前选中到大屏的用户ID */
@property (nonatomic, assign) short prevVideoID; /**< 当前选中到大屏的videoID */

@property(nonatomic,strong)NSLock *ArrLock;

@property(nonatomic,assign)BOOL StateBarIsHidden;
@property(nonatomic,assign)BOOL isScreenShare;
@property(nonatomic,assign)BOOL MicisClose;
@property(nonatomic,assign)BOOL CameraisClose;
@property(nonatomic,assign)BOOL SpeakerisClose;

// ZY修改，横向布局
@property (nonatomic, strong)ELCVFlowLayout *Collectipnlayout;
//@property (nonatomic, strong)UICollectionViewFlowLayout*Collectipnlayout;
@property (nonatomic, strong)MyCell*CurSelectCell;

@end

@implementation PlayerController

-(instancetype)init
{
    self = [super init];
    _MicisClose = NO;
    _CameraisClose = NO;
    _currentJoinRefreshJID = @"";
    _currentLeaveRefreshJID = @"";
    return self;
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [self.view bringSubviewToFront:_PageControl];
    UIDeviceOrientation deviceOrientation = [UIDevice currentDevice].orientation;
    if (UIDeviceOrientationIsLandscape(deviceOrientation))
    {
           [_PageControl setFrame:CGRectMake(0, _Screen_width - 20, _Screen_height, 20)];
//          [_cusCameraView setFrame:CGRectMake(0, 10 + _Screen_width*0.15, _Screen_height, _Screen_width- (10 + _Screen_width*0.15))];
          [_cusCameraView setFrame:CGRectMake(0, 0, _Screen_height, _Screen_width)];
    }
    else if(UIDeviceOrientationIsPortrait(deviceOrientation))
    {
        [_cusCameraView setFrame:CGRectMake(0, 64, _Screen_width, _Screen_height-80 - 64)];
//         [_cusCameraView setFrame:CGRectMake(0, 84 + _Screen_height*0.15, _Screen_width, _Screen_height-80 - (84 + _Screen_height*0.15))];
        if(_PageControl.currentPage == 0)
        {
            [_PageControl setFrame:CGRectMake(0, _Screen_height - 80, _Screen_width, 20)];
        }
        else
        {
            [_PageControl setFrame:CGRectMake(0, _Screen_height - 20, _Screen_width, 20)];
        }
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _isLandScape = false;
//    _isCreatingMeeting = false;
    _curCameraIndex = 1;
    _prevMainVideo = @"";
    _prevVideoID = 0;
    
    self.ArrLock = [[NSLock alloc]init];
    // ZY修改，房间成员集合初始化
    _closeVideoMembers = [NSMutableArray array];
    [self.view setBackgroundColor:[UIColor blackColor]];
    
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];

    
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    [cloudroomVideoSDK setServerAddr:@"www.cloudroom.com"];
    
    NSLog(@"------------ 初始化 --------------");
    
    
    _isDismiss = NO;
    _StateBarIsHidden = NO;
    _isScreenShare = NO;
  
    _SpeakerisClose = NO;
    
}

#pragma mark - 布局视图
-(void)LayoutSubView
{
    // 底部滑动布局
    [self.view addSubview:self.MainScrollView];
    [self.MainScrollView setFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];

    [_MainScrollView setPagingEnabled:YES];
    [_MainScrollView setBounces:NO];
    _MainScrollView.delegate = self;
    _MainScrollView.decelerationRate = UIScrollViewDecelerationRateFast;
    
    [_MainScrollView setContentSize:CGSizeMake(2*_Screen_width, 0)];
    [_MainScrollView setBackgroundColor:[UIColor blackColor]];
    [_MainScrollView setShowsHorizontalScrollIndicator:NO];
    [_MainScrollView setShowsVerticalScrollIndicator:NO];
    
    // 主屏底部View
      _MainVideoView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];
      [_MainVideoView setBackgroundColor:[UIColor blackColor]];
      [self.MainScrollView addSubview:self.MainVideoView];
      _selfCameraView = [[CustomCameraView alloc]initWithFrame:CGRectMake(_Screen_width - _Screen_height*0.13, 74, _Screen_height*0.12, _Screen_height*0.15)];
      [_MainVideoView addSubview:_selfCameraView];
      _selfCameraView.layer.borderWidth = 1.0;
      _selfCameraView.layer.borderColor = [UIColor grayColor].CGColor;

      
      [_selfCameraView setUsrVideoId:nil];

    _cusCameraView = [[CustomCameraView alloc]initWithFrame:CGRectMake(0, 64, _Screen_width, _Screen_height-80 - 64)];
    _cusCameraView.placeImage.image = nil;
    
    _remindLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, _Screen_height*0.4, _Screen_width, _Screen_height*0.2)];
    [_remindLabel setBackgroundColor:[UIColor clearColor]];
    [_remindLabel setFont:[UIFont systemFontOfSize:_backGroundSize]];
    [_remindLabel setTextColor:[UIColor whiteColor]];
    [_remindLabel setTextAlignment:NSTextAlignmentCenter];
    [_remindLabel setText:_backGroundTitle];
    if(_isCreatingMeeting)
    {
        [_remindLabel setHidden:true];
    }
    else
    {
        [_remindLabel setHidden:false];
    }
    
    [self.view addSubview:_remindLabel];
    [self.view bringSubviewToFront:_remindLabel];
//    [_cusCameraView.remindLabel setHidden:NO];
//    [_cusCameraView.remindLabel setFont:[UIFont systemFontOfSize:_backGroundSize]];
//    [_cusCameraView.remindLabel setText:_backGroundTitle];
//    NSLog(@">>>>>>>>>>>>>>>>>>>>>>._backGroundTitle:%@",_backGroundTitle);
//    _cusCameraView = [[CustomCameraView alloc]initWithFrame:CGRectMake(0, 84 + _Screen_height*0.15, _Screen_width, _Screen_height-80 - (84 + _Screen_height*0.15))];
    
    [_MainVideoView addSubview:_cusCameraView];
    [_MainVideoView bringSubviewToFront:_selfCameraView];
    [_cusCameraView setUsrVideoId:nil];


    [_shareView setFrame:CGRectMake(0, 84 + _Screen_height*0.15, _Screen_width, _Screen_height-80 - (84 + _Screen_height*0.15))];
     _shareView.alpha=0;
     [_MainVideoView addSubview:self.shareView];
    // 信息栏
    [self.view addSubview:self.InfoView];

    [_InfoView setBackgroundColor:UIColorFromRGBA(1, 101, 184, 1.0)];

    [_InfoView setFrame:CGRectMake(0, 0, _Screen_width, 64)];

    // 工具栏
    self.TopView = [[UIView alloc]initWithFrame:CGRectMake(0, _Screen_height-60, _Screen_width, 60)];
    [self.view addSubview:self.TopView];
    [_TopView setBackgroundColor:UIColorFromRGBA(25, 25, 25, 1.0)];

    // 换页下标
    [self.view addSubview:self.PageControl];
    [_PageControl setFrame:CGRectMake(0, _Screen_height - 80, _Screen_width, 20)];
    [_PageControl setNumberOfPages:2];
    [_PageControl setUserInteractionEnabled:false];
    //注意事件类型
    [_PageControl addTarget:self action:@selector(dealPage:) forControlEvents:UIControlEventValueChanged];


    // 视频列表
    // ZY修改，支持横向布局
      _Collectipnlayout = [[ELCVFlowLayout alloc]init];
//    _Collectipnlayout = [[UICollectionViewFlowLayout alloc]init];
    //设置滑动方向
    //ZY修改，将滚动方向由竖向变为横向
    _Collectipnlayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    //设置cell大小
    _Collectipnlayout.itemSize = CGSizeMake(_Screen_width/2,_Screen_height/2);
    //设置上下边距
    _Collectipnlayout.minimumLineSpacing = 0;
    _Collectipnlayout.minimumInteritemSpacing = 0;

    


    //创建collectionView
    self.VideoListView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:_Collectipnlayout];



    //属性
    self.VideoListView.backgroundColor = [UIColor blackColor];//UIColorFromRGBA(31, 47, 65, 1.0);
    [self.VideoListView addObserver:self forKeyPath:@"contentOffset" options:NSKeyValueObservingOptionNew context:nil];
    //数据源
    self.VideoListView.dataSource = self;
    self.VideoListView.delegate = self;
    //注册cell
    [self.VideoListView registerClass:[MyCell class] forCellWithReuseIdentifier:reuseIdentifier];

    [_MainScrollView addSubview:self.VideoListView];

    [_VideoListView setPagingEnabled:YES];
    [_VideoListView setShowsHorizontalScrollIndicator:NO];
    [_VideoListView setShowsVerticalScrollIndicator:NO];
    [self.VideoListView setFrame:CGRectMake(_Screen_width, 0, _Screen_width, _Screen_height)];


    // 退出
    _EndButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_InfoView addSubview:_EndButton];


    [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
    [_EndButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_EndButton setFrame:CGRectMake(_Screen_width*0.95 - 40, 20, 40, 40)];

    [_EndButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];





    // 外放按钮
    _SoundButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_InfoView addSubview:_SoundButton];

    [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];

    _SoundButton.imageView.contentMode = UIViewContentModeScaleAspectFit;

    [_SoundButton setFrame:CGRectMake(_Screen_width*0.05, 20, 40, 40)];

    [_SoundButton addTarget:self action:@selector(SoundBtAction) forControlEvents:(UIControlEventTouchUpInside)];


    // 房间标题
    [_InfoView addSubview:self.TitleLabel];

    [_TitleLabel setFrame:CGRectMake(_Screen_width*0.05 + 40 , 20, _Screen_width*0.95 - 40 - (_Screen_width*0.05 + 40), 40)];
    [_TitleLabel setTextAlignment:NSTextAlignmentCenter];
    [_TitleLabel setTextColor:[UIColor whiteColor]];
    [_TitleLabel setUserInteractionEnabled:true];
    UILongPressGestureRecognizer *longReg = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(titleLongPress)];
    [_TitleLabel addGestureRecognizer:longReg];



    // 麦克风按钮
    _MicButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_TopView addSubview:_MicButton];

    [_MicButton setBackgroundImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
    [_MicButton setFrame:CGRectMake(_Screen_width*0.15, 10, 40, 40)];
    [_MicButton addTarget:self action:@selector(MicrophoneBtAction) forControlEvents:(UIControlEventTouchUpInside)];



    // 摄像头按钮
    _CameraButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_TopView addSubview:_CameraButton];
    

    [_CameraButton setBackgroundImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
    [_CameraButton setFrame:CGRectMake(_Screen_width*0.85-40, 10, 40, 40)];
    [_CameraButton addTarget:self action:@selector(CameraBtAction) forControlEvents:(UIControlEventTouchUpInside)];
    
}

- (void)titleLongPress
{
    UIPasteboard *pboard = [UIPasteboard generalPasteboard];
    if(_isCreatingMeeting)
    {
        pboard.string = [NSString stringWithFormat:@"%d",_createMeetInfo.ID];
    }
    else
    {
        pboard.string = [NSString stringWithFormat:@"%d",_meetInfo.ID];
    }
    [HUDUtil hudShow:@"房间号已复制!" delay:1 animated:YES];
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString:@"contentOffset"]){
        CGPoint offset = [change[NSKeyValueChangeNewKey] CGPointValue];
        // ZY修改，设置为记住横向滑动量
        if(_isLandScape)
        {
                _lastVideoCollectionViewOffsetYLandScapeNum =  (offset.x/_Screen_height);
        }
        else
        {

                _lastVideoCollectionViewOffsetYPortitNum =  (offset.x/_Screen_width);
        }
        
    }
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    _Screen_width = [UIScreen mainScreen].bounds.size.width;
    _Screen_height = [UIScreen mainScreen].bounds.size.height;
    // 不灭屏
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    
    // 更新代理
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    [cloudroomVideoMgr setMgrCallback:self];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    [cloudroomVideoMeeting setMeetingCallBack:self];
    
    [self LayoutSubView];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_MainScrollView setContentSize:CGSizeMake(2*_Screen_width, 0)];
//    [self MainVideoTapAction];
}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    [cloudroomVideoMgr removeMgrCallback:self];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    [cloudroomVideoMeeting removeMeetingCallBack:self];
    
    [self.VideoListView removeObserver:self forKeyPath:@"contentOffset" context:nil];
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    
}


-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    _isDismiss = YES;
}


-(void)StartCloudRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo isMicOn:(BOOL)micOn isCameraOn:(BOOL)cameraOn isSelfCreatingRoom:(NSString *)isSelfCreateRoom;
{
    _MicisClose = !micOn;
    _CameraisClose = !cameraOn;
    
    _titleStr = mainVideo;

//    NSLog(@">>>>>>>>>>>>>>isSelfCreateRoom为：%@ === isCameraOn为：%d",isSelfCreateRoom,cameraOn);

    // 如果是通过Web API创建的永久房间
    if([[isSelfCreateRoom lowercaseString]isEqualToString:@"true"])
    {
//        NSLog(@">>>>>>>>>>>>>>创建CreateMeetInfo");
//        NSLog(@">>>>>>>>>>>>>>传入的房间号为:%d",RoomID);
        _createMeetInfo = [[MeetInfo alloc]init];
        [_createMeetInfo setID:RoomID];
        [_createMeetInfo setPswd:Psw];
        _isCreatingMeeting = true;
        _m_CreateUserid = userid;
        _m_CreateUserNickName = nickName;
    }
    else
    {
        _meetInfo = [[MeetInfo alloc] init];
        [_meetInfo setID:RoomID];
        [_meetInfo setPswd:Psw];
        _isCreatingMeeting = false;
        _m_nickname =nickName;
        _m_Userid =userid;
    }
        
    // 入会操作
    [self _enterMeeting];
    
}



/* 入会操作 */
- (void)_enterMeeting {
    
//    NSLog(@">>>>>>>>>>>>>>进入房间");
    if(_isCreatingMeeting)
    {
//        NSLog(@">>>>>>>>>>>>>>>>>>>>>>_isCreatingMeeting为true,进入房间");
        if (_createMeetInfo.ID > 0) {
//              NSLog(@">>>>>>>>>>>>>>>>>>>>>>_createMeetInfo ID大于0,进入房间");
              [HUDUtil hudShowProgress:@"正在连接中..." animated:YES];
              CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
              [cloudroomVideoMeeting enterMeeting:_createMeetInfo.ID pswd:_createMeetInfo.pswd userID:_m_CreateUserid nikeName:_m_CreateUserNickName];
        }
    }
    else
    {
        if (_meetInfo.ID > 0) {
              [HUDUtil hudShowProgress:@"正在连接中..." animated:YES];
              CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
              [cloudroomVideoMeeting enterMeeting:_meetInfo.ID pswd:_meetInfo.pswd userID:_m_Userid nikeName:_m_nickname];
        }
    }
}

#pragma mark - 创建房间
-(void)CreateCloudRoomWithUserID:(NSString *)userID NickName:(NSString *)nickName withReturnRoomID:(ReturnRoomIDBlock)block isMicOn:(BOOL)micOn isCameraOn:(BOOL)cameraOn
{
    _MicisClose = !micOn;
    _CameraisClose = !cameraOn;
    self.callbackBlock = block;
    _m_CreateUserid = userID;
    _m_CreateUserNickName = nickName;
    [self _handleLogin];
}

#pragma mark - 创建房间需要登录
- (void)_handleLogin {
        
    MeetingHelper *meetingHelper = [MeetingHelper shareInstance];
    [meetingHelper readInfo];
      
    if ([NSString stringCheckEmptyOrNil:meetingHelper.account] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.pswd] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.server])
    {
          [meetingHelper resetInfo];
    }
    
    NSString *nickname = meetingHelper.nickname;
    if ([NSString stringCheckEmptyOrNil:nickname]) {
        nickname = _m_CreateUserNickName;
    }
    
    // 云屋SDK登陆账号,实际开发中,请联系云屋工作人员获取
    NSString *account = meetingHelper.account;
    // 密码通过MD5以后
    NSString *pswd = meetingHelper.pswd;
    // 服务器地址
    NSString *server = meetingHelper.server;
    
    if ([NSString stringCheckEmptyOrNil:server]) {
        [HUDUtil hudShow:@"服务器地址不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:account]) {
        [HUDUtil hudShow:@"账号不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:pswd]) {
        [HUDUtil hudShow:@"密码不能为空!" delay:3 animated:YES];
        return;
    }
    
    NSString *md5Pswd = [NSString md5:meetingHelper.pswd];
    
    MLog(@"server:%@ nickname:%@ account:%@ pswd:%@", server, nickname, account, md5Pswd);
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    LoginDat *loginData = [[LoginDat alloc] init];
    [loginData setNickName:nickname];
    [loginData setAuthAcnt:account];
    [loginData setAuthPswd:md5Pswd];
    [loginData setPrivAcnt:nickname];
    
    [meetingHelper writeAccount:account pswd:pswd server:server];
    [meetingHelper writeNickname:nickname];
    
    // 设置服务器地址
    [cloudroomVideoSDK setServerAddr:server];
    
    [HUDUtil hudShowProgress:@"正在连接中..." animated:YES];
    
    // 开始上传日志
    [[CloudroomVideoSDK shareInstance] startLogReport:nickname server:@"logserver.cloudroom.com:12005"];
    
    // 发送"登录"指令
    NSString *cookie = [NSString stringWithFormat:@"%f",CFAbsoluteTimeGetCurrent()];
    [cloudroomVideoMgr login:loginData cookie:cookie];
    
    
   
}
// 生成随机码
- (NSInteger)_randomNumFrom:(NSInteger)from to:(NSInteger)to {
    return (from + (NSInteger)(arc4random() % (to - from + 1)));
}

#pragma mark - VideoMgrDelegate
// 登录成功
- (void)loginSuccess:(NSString *)usrID cookie:(NSString *)cookie {
//    [HUDUtil hudHiddenProgress:YES];
//    [HUDUtil hudShowProgress:@"正在创建房间..." animated:YES];
    NSLog(@">>>>>>>>>>>>>>登录用户ID为:%@",usrID);
//    _m_CreateUserid = usrID;
    _titleStr = usrID;
    NSString *createCookie = [NSString stringWithFormat:@"%f", CFAbsoluteTimeGetCurrent()];
        // 发送"创建房间"命令(不设置密码)
    [[CloudroomVideoMgr shareInstance] createMeeting:_titleStr createPswd:NO cookie:createCookie];
}

// 登录失败
- (void)loginFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
        
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>login err sdkErr:%u",sdkErr);
    if (sdkErr == CRVIDEOSDK_NOSERVER_RSP) {
        [HUDUtil hudShow:@"服务器无响应" delay:3 animated:YES];
    }
    else if (sdkErr == CRVIDEOSDK_LOGINSTATE_ERROR) {
        [HUDUtil hudShow:@"登陆状态不对" delay:3 animated:YES];
        [[CloudroomVideoMgr shareInstance] logout];
    }
    else if (sdkErr == CRVIDEOSDK_SOCKETTIMEOUT) {
        [HUDUtil hudShow:@"网络超时" delay:3 animated:YES];
    }
    else {
        [HUDUtil hudShow:@"登录失败" delay:3 animated:YES];
    }
    [self _jumpToPMeeting];
}

#pragma mark - 创建房间回调
// 创建房间成功回调
- (void)createMeetingSuccess:(MeetInfo *)meetInfo cookie:(NSString *)cookie {
//    [HUDUtil hudHiddenProgress:YES];
    NSLog(@">>>>>>>>>>>>房间ID为：%d",meetInfo.ID);
    _titleStr = [NSString stringWithFormat:@"%d",meetInfo.ID];
    _createMeetInfo = meetInfo;
    //进入房间
    [self _enterCreateRoomMeeting];
}

// 创建房间失败回调
- (void)createMeetingFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@"创建房间失败：%u",sdkErr );
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:@"创建房间失败" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeeting];
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
           
    if(version.doubleValue>=13) {
               
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:NO completion:nil];
}

#pragma mark - 进入自己创建的房间
- (void)_enterCreateRoomMeeting{
    if (_createMeetInfo.ID > 0) {
           _isCreatingMeeting = true;
           CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
           [cloudroomVideoMeeting enterMeeting:_createMeetInfo.ID pswd:_createMeetInfo.pswd userID:_m_CreateUserid nikeName:_m_CreateUserNickName];
       }
}

#pragma mark - 视频设备状态变化
- (void)videoDevChanged:(NSString *)userID
{
    NSLog(@"~~~~~~~~~~~~~~~~~~~~~ videoDevChanged");
    [self _setCamera];
    [self _updateCamera];

    [self _updateVideoInfo:userID];
}

#pragma mark - 自己摄像头视频设备状态变化
- (void)videoStatusChanged:(NSString *)userID oldStatus:(VIDEO_STATUS)oldStatus newStatus:(VIDEO_STATUS)newStatus {
     NSLog(@"~~~~~~~~~~~~~~~~~~~~~ videoStatusChanged");
    [self _setCamera];
    [self _updateCamera];
    
    // ZY修改，如果是自己的摄像头在主视频上，关闭时清空主视频
    if([userID isEqualToString:[[CloudroomVideoMeeting shareInstance]getMyUserID]])
    {
        // 关闭自己的外景主视频
        if(newStatus == VCLOSE || newStatus == VNULL)
        {
            if([self.cusCameraView.usrVideoId.userId isEqualToString: userID])
            {
                [self.cusCameraView clearFrame];
                self.cusCameraView.usrVideoId = nil;
            }
        }
         // 如果主视频为空，打开自己的外景主视频
        else if(newStatus == VOPEN)
        {
                if(self.cusCameraView.usrVideoId == nil){
                    
                    bool hasHolder = false;
                      NSMutableArray <MemberInfo *> *arr = [[CloudroomVideoMeeting shareInstance] getAllMembers];
                      for(int i=0;i<arr.count;i++)
                      {
                              MemberInfo *info = arr[i];
                              if(_holderJID && [info.userId containsString:_holderJID])
                              {
                                  hasHolder = true;
                                  break ;
                              }
                      }
                      if(hasHolder)
                      {
                          NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
                                                if([mainVideo isEqualToString:@""] && _members.count!=0)
                                                {
                                                      UsrVideoId *uobj = [_members firstObject];
                                          
                                                      [_cusCameraView setUsrVideoId:uobj];
                                          
                                                      _curMainVideo =uobj.userId;
                                                      _curMainVideoID =uobj.videoID;
                                          
                                                }else if (![mainVideo isEqualToString:@""])
                                                {
                                                      UsrVideoId *videotest =[[UsrVideoId alloc]init];
                                                      videotest.userId = mainVideo;
                                                      videotest.videoID = [[CloudroomVideoMeeting shareInstance] getDefaultVideo:mainVideo];
                                              
                                                      [_cusCameraView setUsrVideoId:videotest];
                                                      _curMainVideo = mainVideo;
                                                      _curMainVideoID = videotest.videoID;
                                                }
                          
                      }
                      
                 }
        }
    }
    [self _updateVideoInfo:userID];
}

/* 更新摄像头开关 UI */
- (void)_updateCamera {
    VIDEO_STATUS status = [SDKUtil getLocalCameraStatus];
    
    switch (status) {
        case VCLOSE:
            
            [_CameraButton setBackgroundImage:[UIImage imageNamed:@"bt_camera_Off"] forState:UIControlStateNormal];
            
            break;
        case VOPEN:
            [_CameraButton setBackgroundImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
            break;
            
        default:
            break;
    }
    
    
}

#pragma mark - 本地音频设备有变化
- (void)audioDevChanged{
    [self _updateMic];
}

#pragma mark - 音频设备状态变化
- (void)audioStatusChanged:(NSString *)userID oldStatus:(AUDIO_STATUS)oldStatus newStatus:(AUDIO_STATUS)newStatus {

    NSString *myUserID = [[CloudroomVideoMeeting shareInstance] getMyUserID];
    if([myUserID isEqualToString:userID])
    {
        [self _updateMic];
    }
     [UIView performWithoutAnimation:^{
         //刷新界面
         [self.VideoListView reloadData];
     }];
}

/* 更新麦克风开关 UI */
- (void)_updateMic {
    AUDIO_STATUS status = [SDKUtil getLocalMicStatus];
    
    switch (status) {
        case ACLOSE:
            
            [_MicButton setBackgroundImage:[UIImage imageNamed:@"bt_mic_Off"] forState:UIControlStateNormal];

            
            break;
        case AOPEN:
            [_MicButton setBackgroundImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
            
            
            break;
            
        default:
            break;
    }
    

}

#pragma mark - 云屋代理 VideoMeetingDelegate
// 入会结果
- (void)enterMeetingRslt:(CRVIDEOSDK_ERR_DEF)code {
    
    [HUDUtil hudHiddenProgress:YES];
    
    if (code == CRVIDEOSDK_NOERR) {
        [self _enterMeetingSuccess];
    } else if (code == CRVIDEOSDK_MEETROOMLOCKED) {
        [self _enterMeetingFail:@"房间已加锁!"];
    } else {
        NSLog(@">>>>>进入房间失败！错误码：%d",code);
        [self _enterMeetingFail:@"进入房间失败!"];
    }
}

- (void)userEnterMeeting:(NSString *)userID {
    _currentJoinRefreshJID = userID;
    if(_holderJID && [userID containsString:_holderJID])
    {
        // 获取主视频
        NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
        short videoID = [[CloudroomVideoMeeting shareInstance]getDefaultVideo:mainVideo];
        UsrVideoId *mainVideoID = [[UsrVideoId alloc]init];
        mainVideoID.userId = mainVideo;
        mainVideoID.videoID = videoID;
        [self.cusCameraView setUsrVideoId:mainVideoID];
        [_remindLabel setHidden:true];
    }
//    NSString *text = [NSString stringWithFormat:@"%@进入房间!",[[CloudroomVideoMeeting shareInstance] getNickName: userID]];
//    [HUDUtil hudShow:text delay:2 animated:YES];

    [self _updateVideoInfo:userID];

}

- (void)userLeftMeeting:(NSString *)userID {
    
//    [self _updateVideoInfo:userID];
    _currentLeaveRefreshJID = userID;
    // ZY修改，改变离开房间刷新机制
    NSMutableArray <MemberInfo *> *info = [[CloudroomVideoMeeting shareInstance]getAllMembers];
    
    NSMutableArray<UsrVideoId *> *remove = [NSMutableArray array];
    
    for (UsrVideoId *obj2 in self.members)
    {
              BOOL find = NO;

              for (MemberInfo *subInfo in info)
              {
                  if ([subInfo.userId isEqualToString:obj2.userId])
                  {
                      find = YES;
                      break;
                  }
              }


              if (find == NO)
              {

                  [remove addObject:obj2];
                  NSLog(@"-------------->离开房间的用户为：%@",obj2.userId);
              }
    }
    
    // ZY修改，如果主界面焦点视频是离开的人的话
       for(UsrVideoId *info in remove)
       {
            if(self.cusCameraView.usrVideoId == info)
            {
                [self.cusCameraView clearFrame];
                self.cusCameraView.usrVideoId = nil;
            }
       }
    
    [self.members removeObjectsInArray:remove];
    
   
  
    [UIView performWithoutAnimation:^{
        [self.VideoListView reloadData];
    }];
    
    // ZY修改,当房间只剩下自己时离开房间
      // 统计房间人数信息
    NSString *str = _titleStr;
    self.TitleLabel.text = @"";
    NSMutableArray *arr = [[CloudroomVideoMeeting shareInstance] getAllMembers];
    NSString *newstr = [str stringByAppendingString:[NSString stringWithFormat:@"(在线%lu人)",(unsigned long)arr.count]];
    [self.TitleLabel setText:newstr];
    if(arr.count == 1)
    {
        [self _jumpToPMeeting];
    }
}

// 房间被结束
- (void)meetingStopped{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:@"房间已结束!" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeeting];
        
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:YES completion:^{}];
}


// 房间掉线
- (void)meetingDropped{
    NSLog(@"房间掉线!");
    [self reEnterMeetingAlert:@"房间掉线"];
}

/* 房间掉线操作 */
- (void)reEnterMeetingAlert:(NSString*)message{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"离开房间" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        _isCreatingMeeting = false;
        [self _jumpToPMeeting];
    }];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"重新登录" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        // 离开房间
        [[CloudroomVideoMeeting shareInstance] exitMeeting];
        // 重新入会
        if(_isCreatingMeeting)
        {
            [self _enterCreateRoomMeeting];
        }
        else
        {
           [self _enterMeeting];
        }

    }];
    [alertController addAction:cancelAction];
    [alertController addAction:doneAction];

    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:NO completion:^{}];
    
}

/* 入会成功 */
- (void)_enterMeetingSuccess {

    if(_CameraisClose)
    {
        [SDKUtil closeLocalCamera];
    }
    else
    {
        [SDKUtil openLocalCamera];
    }
    if(_MicisClose)
    {
        [SDKUtil closeLocalMic];
    }
    else
    {
        [SDKUtil openLocalMic];
    }
    
    [self _setupForCamera];
    
    [_TitleLabel setText:_titleStr];
    // 订阅摄像头
    [self _setCamera];
    
    // 如果是加入房间的话，判断房间人数，如果只有自己一个人的话，设为主持人
//    if(!_isCreatingMeeting)
//    {
//        NSMutableArray <MemberInfo *> * arr = [[CloudroomVideoMeeting shareInstance]getAllMembers];
//        NSLog(@">>>>>>>>>>>>>>>>加入房间判断房间人数为：%ld",(unsigned long)arr.count);
//        // 如果只有一个人的话，设置为主持人
//        if(arr.count == 1)
//        {
//            _isCreatingMeeting = true;
//        }
//    }
    
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>进入房间成功");
    // 如果是创建房间则设为主视频
    if(_isCreatingMeeting)
    {
        CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
        [cloudroomVideoMeeting setMainVideo:_m_CreateUserid];
        if(self.callbackBlock && _createMeetInfo.ID > 0)
            self.callbackBlock(_createMeetInfo.ID);
    }
    
    if(_isCreatingMeeting)
    {
        if(self.roomIDBlock && _createMeetInfo.ID > 0)
            self.roomIDBlock(_createMeetInfo.ID);
    }
    else
    {
        if(self.roomIDBlock && _meetInfo.ID > 0)
            self.roomIDBlock(_meetInfo.ID);
    }
   
    // 如果是加入房间并且是自己摄像头关闭的话就主动获取主视频
    if(_CameraisClose && !_isCreatingMeeting)
    {
        NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
        short mainVideoID = [[CloudroomVideoMeeting shareInstance]getDefaultVideo:mainVideo];
        
        UsrVideoId *mainVideoParam = [[UsrVideoId alloc]init];
        mainVideoParam.userId = mainVideo;
        mainVideoParam.videoID = mainVideoID;
        [self.cusCameraView setUsrVideoId:mainVideoParam];
        
    }

    // 如果加入房间成功，并且里面有主持人的话,就把提示隐藏了
    NSMutableArray <MemberInfo *> *arr = [[CloudroomVideoMeeting shareInstance] getAllMembers];
    for(int i=0;i<arr.count;i++)
    {
        MemberInfo *info = arr[i];
        if(_holderJID && [info.userId containsString:_holderJID])
        {
            [_remindLabel setHidden:true];
        }
    }
    
    [self _updateVideoInfo:@""];
    
    // 设置默认分辨率: 360*360
    [SDKUtil setRatio:VSIZE_SZ_360];
    // 设置默认帧率: 15
    [SDKUtil setFps:25];
    // 设置默认优先级: 画质优先
    //    [SDKUtil setPriority:25 min:22];
    [SDKUtil setPriority:36 min:22];
    // 设置默认宽高比
    [SDKUtil setLocalCameraWHRate:WHRATE_16_9];
    
    
}



#pragma mark -主视频回调

- (void)notifyMainVideo:(NSString *)userID
{
    
    WeakSelf
    NSLog(@">>>>>>>>>>>>>>>>>>>>>.接收到%@的主视频通知",userID);
    NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
    _curMainVideo = mainVideo;

    short videoID = [[CloudroomVideoMeeting shareInstance] getDefaultVideo:mainVideo];
    _curMainVideoID = videoID;

    __block NSInteger index = 0;
    // 绘制主视频
    [_members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {


        if([mainVideo isEqualToString:obj.userId] && videoID == obj.videoID)
        *stop = true;

        if (*stop == YES) {

            [weakSelf.cusCameraView setUsrVideoId:obj];
            index = [self.members indexOfObject:obj];
        }
        else
        {
            UsrVideoId *vID = [[UsrVideoId alloc]init];
            vID.userId = mainVideo;
            vID.videoID = videoID;
            [weakSelf.cusCameraView setUsrVideoId:vID];
        }

    }];
    if(self.members.count == 0)
    {
        UsrVideoId *vID = [[UsrVideoId alloc]init];
        vID.userId = mainVideo;
        vID.videoID = videoID;
        [weakSelf.cusCameraView setUsrVideoId:vID];
    }

    // ZY修改，刷新
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index inSection:0];
    MyCell *cell =(MyCell*)[_VideoListView cellForItemAtIndexPath:indexPath];
//    [cell.mainVideoButton setTitleColor:[self colorWithHexString:@"#0165B8" alpha:1.0f] forState:  UIControlStateNormal];
    [cell.mainVideoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [cell.mainVideoButton.titleLabel setFont:[UIFont systemFontOfSize:14]];
    [cell.mainVideoButton setBackgroundColor:[UIColor blackColor]];
    [cell.mainVideoButton.layer setOpacity:0.6];
    [cell.mainVideoButton.layer setCornerRadius:2.0f];
    [cell.mainVideoButton setTitle:@"焦点视频" forState:UIControlStateNormal];
    
    if(_prevMainVideo.length > 0)
    {
        __block NSInteger index1 = 0;
          // 绘制主视频
          [_members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {


              if([_prevMainVideo isEqualToString:obj.userId] && _prevVideoID == obj.videoID)
              *stop = true;

              if (*stop == YES) {

                  index1 = [self.members indexOfObject:obj];
              }

          }];
        
        NSIndexPath *indexPath1 = [NSIndexPath indexPathForItem:index1 inSection:0];
        MyCell *cell1 =(MyCell*)[_VideoListView cellForItemAtIndexPath:indexPath1];
        [cell1.mainVideoButton setTitleColor:[UIColor whiteColor] forState:  UIControlStateNormal];
        [cell1.mainVideoButton.titleLabel setFont:[UIFont systemFontOfSize:13]];
        [cell1.mainVideoButton setBackgroundColor:[UIColor blackColor]];
        [cell1.mainVideoButton.layer setOpacity:0.6];
        [cell1.mainVideoButton.layer setCornerRadius:2.0f];
        [cell1.mainVideoButton setTitle:@"设为焦点视频" forState:UIControlStateNormal];
    }
    
    _prevMainVideo = mainVideo;
    _prevVideoID = videoID;
//    [self _updateVideoInfo:userID];

}


#pragma mark - 屏幕共享

// 屏幕共享操作通知
- (void)notifyScreenShareStarted{
    [HUDUtil hudShow:@"屏幕共享已开始" delay:2 animated:YES];
    
    _shareView.alpha = 1.0;
    _cusCameraView.alpha = 0;
    _isScreenShare = YES;
    
    [self _updateVideoInfo:@""];
    
}

- (void)notifyScreenShareStopped{
    [HUDUtil hudShow:@"屏幕共享已结束" delay:2 animated:YES];
    
    _shareView.alpha = 0;
    _cusCameraView.alpha=1.0;
    _isScreenShare = NO;
    
    [self _updateVideoInfo:@""];
}


/**
 入会失败
 @param message 失败信息
 */
- (void)_enterMeetingFail:(NSString *)message {
    [HUDUtil hudShow:message delay:3 animated:YES];
  
    if (_meetInfo.ID > 0 || _createMeetInfo.ID > 0) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:message preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            _isCreatingMeeting = false;
            [self _jumpToPMeeting];
            
        }];
        UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"重试" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //重新入会时也要分创建的房间还是加入的房间
            if(_isCreatingMeeting)
               [self _enterCreateRoomMeeting];
            else
               [self _enterMeeting];
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:doneAction];
        NSString *version = [UIDevice currentDevice].systemVersion;
        
        if(version.doubleValue>=13) {
            
            alertController.modalPresentationStyle = UIModalPresentationFullScreen;
        }
        [self presentViewController:alertController animated:NO completion:nil];
    }
}



/**
 初始化摄像头信息
 */
- (void)_setupForCamera {
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSString *myUserID = [cloudroomVideoMeeting getMyUserID];
    short curVideoID = [cloudroomVideoMeeting getDefaultVideo:myUserID];
    NSMutableArray <UsrVideoInfo *> *videoes = [cloudroomVideoMeeting getAllVideoInfo:myUserID];
    NSArray<UsrVideoInfo *> *cameraArray = [videoes copy];
    
    for (UsrVideoInfo *video in videoes) {
        if (curVideoID == 0) { // 没有默认设备
            curVideoID = video.videoID;
            [cloudroomVideoMeeting setDefaultVideo:myUserID videoID:curVideoID];
        }
    }
    
    if ([cameraArray count] <= 0) {
        NSLog(@"获取摄像头设备为空!");
        return;
    }
    
    _cameraArray = cameraArray;
}



/**
 设置摄像头
 */
- (void)_setCamera {
    if ([_cameraArray count] ==0) {
        MLog(@"没有摄像头!");
        return;
    }
    
    if (_curCameraIndex >= [_cameraArray count]) {
        MLog(@"摄像头索引越界!");
        return;
    }
    
    // 设置摄像头设备
    UsrVideoInfo *video = [_cameraArray objectAtIndex:_curCameraIndex];
    [[CloudroomVideoMeeting shareInstance] setDefaultVideo:video.userId videoID:video.videoID];
    MLog(@"当前摄像头为:%@", video.userId);
}

/* 更新房间成员 */
- (void)_updateVideoInfo:(NSString*)userID{
    
    
    WeakSelf
    [_ArrLock lock];

    // 统计房间人数信息
    NSString *str = _titleStr;
    self.TitleLabel.text = @"";
    NSMutableArray *arr = [[CloudroomVideoMeeting shareInstance] getAllMembers];
    NSString *newstr = [str stringByAppendingString:[NSString stringWithFormat:@"(在线%lu人)",(unsigned long)arr.count]];
    [self.TitleLabel setText:newstr];
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    
    NSMutableArray <UsrVideoId *> *watchableVideos = [cloudroomVideoMeeting getWatchableVideos];

    // ZY修改，刷新机制改变
    NSMutableArray <UsrVideoId *> *diff = [NSMutableArray array];

    // 找到不同元素
    if ([self.members count] <= 0) {


        [diff addObjectsFromArray:watchableVideos];
    }
    else
    {
        for (UsrVideoId *obj1 in watchableVideos)
        {
            BOOL find = NO;

            for (UsrVideoId *obj2 in self.members)
            {
                if ([obj1.userId isEqualToString:obj2.userId] && obj1.videoID == obj2.videoID)
                {
                    find = YES;
                    break;
                }
            }


            if (find == NO)
            {

                [diff addObject:obj1];
                NSLog(@"------添加--------->%@",obj1.userId);
            }
        }
    }
    
    [_members addObjectsFromArray:diff];
    //ZY修改，如果在member中存在但是在watchableVideo中没有的
    // 找到删除元素
    [_closeVideoMembers removeAllObjects];
    for (UsrVideoId *obj1 in self.members)
    {
               BOOL find = NO;
               for (UsrVideoId *obj2 in watchableVideos)
               {
                            if ([obj1.userId isEqualToString:obj2.userId] && obj1.videoID == obj2.videoID)
                            {
                                find = YES;
                                break;
                            }
               }
                        
               if (find == NO)
               {
                   [_closeVideoMembers addObject:obj1];
               }
    }
    NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
    _curMainVideo = mainVideo;

    short videoID = [[CloudroomVideoMeeting shareInstance] getDefaultVideo:mainVideo];
    _curMainVideoID = videoID;
    
    NSString *myUserID = [[CloudroomVideoMeeting shareInstance]getMyUserID];
    
//    if(weakSelf.cusCameraView.usrVideoId == nil){
//
//      if([mainVideo isEqualToString:@""] && _members.count!=0)
//      {
//            UsrVideoId *uobj = [_members firstObject];
//
//            [_cusCameraView setUsrVideoId:uobj];
//
//            _curMainVideo =uobj.userId;
//            _curMainVideoID =uobj.videoID;
//
//      }else if (![mainVideo isEqualToString:@""])
//      {
//        UsrVideoId *videotest =[[UsrVideoId alloc]init];
//        videotest.userId =mainVideo;
//        videotest.videoID = [cloudroomVideoMeeting getDefaultVideo:mainVideo];
//
//        [_cusCameraView setUsrVideoId:videotest];
//        _curMainVideo = mainVideo;
//        _curMainVideoID = videotest.videoID;
//      }
//    }

    if(weakSelf.selfCameraView.usrVideoId == nil && _members.count!=0)
    {

        UsrVideoId *videotest =[[UsrVideoId alloc]init];
        videotest.userId =myUserID;
        videotest.videoID = [cloudroomVideoMeeting getDefaultVideo:myUserID];

        [weakSelf.selfCameraView setUsrVideoId:videotest];

    }
    
     [UIView performWithoutAnimation:^{
            //刷新界面
            [self.VideoListView reloadData];
     }];
    
    [_ArrLock unlock];
}



#pragma mark - getter & setter
- (NSMutableArray<UsrVideoId *> *)members {
    if (!_members) {
        _members = [NSMutableArray array];
    }
    
    return _members;
}

-(UIScrollView *)MainScrollView
{
    if(_MainScrollView == nil)
    {
        _MainScrollView = [[UIScrollView alloc]initWithFrame:self.view.frame];
    }

    return  _MainScrollView;
}

-(UIView *)InfoView
{
    if(_InfoView == nil)
    {
        _InfoView = [[UIView alloc]init];
    }

    return  _InfoView;
}

-(UIPageControl *)PageControl
{
    if(_PageControl == nil)
    {
        _PageControl = [[UIPageControl alloc]init];
    }
    
    return  _PageControl;
}

-(CLShareView *)shareView
{
    if(_shareView == nil)
    {
        _shareView = [[CLShareView alloc]initWithFrame:self.view.frame];
    }
    
    return  _shareView;
}

-(UILabel *)TitleLabel
{
    if(_TitleLabel == nil)
    {
        _TitleLabel = [[UILabel alloc] init];
    }
    
    return  _TitleLabel;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];


}




#pragma mark  强制横屏代码

// 是否隐藏状态栏
- (BOOL)prefersStatusBarHidden
{
    
    return _StateBarIsHidden;
}





#pragma mark - collectionView Delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //    ZY修改, 修改页面数量
    [self.PageControl setNumberOfPages:ceil(self.members.count/4.0f) + 1];
    return self.members.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    
    MyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    UsrVideoId *userInfo = _members[indexPath.item];


    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSString *nickName = [cloudroomVideoMeeting getNickName:userInfo.userId];

    NSString *nName = [NSString stringWithFormat:@"  %@",nickName];
    [cell.titleLabel setText:nName];

    [cell.bottomView setHidden:!_isCreatingMeeting];
    
    if(_currentJoinRefreshJID.length > 0)
    {
        if(userInfo.userId == _currentJoinRefreshJID)
        {
            [cell.VideoView clearFrame];
            [cell.VideoView setUsrVideoId:nil];
            _currentJoinRefreshJID = @"";
        }
    }

    
    [cell.VideoView setUsrVideoId:userInfo];
    

    if(_isCreatingMeeting)
    {
        AUDIO_STATUS astatus = [cloudroomVideoMeeting getAudioStatus:userInfo.userId];

        if(astatus == ACLOSE || astatus == ANULL || astatus == AUNKNOWN)
        {
            NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 用户%@的麦克风为关",userInfo.userId);
            [cell.micButton setImage:[UIImage imageNamed:@"bt_mic_Off"] forState:UIControlStateNormal];
        }
        else if(astatus == AOPEN)
        {
             NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 用户%@的麦克风为开",userInfo.userId);
             [cell.micButton setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
        }
        // ZY修改，改变刷新视频开关的方式
        if([_closeVideoMembers containsObject:userInfo])
        {
               NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 用户%@的摄像头为关",userInfo.userId);
               [cell.cameraButton setImage:[UIImage imageNamed:@"bt_camera_Off"] forState:UIControlStateNormal];
               [cell.VideoView clearFrame];
        }
        else
        {
               NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 用户%@的摄像头为开",userInfo.userId);
               [cell.cameraButton setImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
               [cell.VideoView setUsrVideoId:userInfo];
        }

        // 如果自己是主视频的话就隐藏焦点视频的按钮
        NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
        short videoID = [[CloudroomVideoMeeting shareInstance]getDefaultVideo:mainVideo];
        if([userInfo.userId isEqualToString:mainVideo]&&userInfo.videoID == videoID)
        {
//            [cell.mainVideoButton setTitleColor:[self colorWithHexString:@"#0165B8" alpha:1.0f] forState:  UIControlStateNormal];
            [cell.mainVideoButton setTitleColor:[UIColor whiteColor] forState:  UIControlStateNormal];
            [cell.mainVideoButton.titleLabel setFont:[UIFont systemFontOfSize:14]];
            [cell.mainVideoButton setBackgroundColor:[UIColor blackColor]];
            [cell.mainVideoButton.layer setOpacity:0.6];
            [cell.mainVideoButton.layer setCornerRadius:2.0f];
            [cell.mainVideoButton setTitle:@"焦点视频" forState:UIControlStateNormal];
        }
        else
        {
             [cell.mainVideoButton setTitleColor:[UIColor whiteColor] forState:  UIControlStateNormal];
             [cell.mainVideoButton.titleLabel setFont:[UIFont systemFontOfSize:13]];
             [cell.mainVideoButton setBackgroundColor:[UIColor blackColor]];
             [cell.mainVideoButton.layer setOpacity:0.6];
             [cell.mainVideoButton.layer setCornerRadius:2.0f];
             [cell.mainVideoButton setTitle:@"设为焦点视频" forState:UIControlStateNormal];
        }
    }
    [cell.micButton addTarget:self action:@selector(cellMicOperation:) forControlEvents:UIControlEventTouchUpInside];
    [cell.cameraButton addTarget:self action:@selector(cellCamOperation:) forControlEvents:UIControlEventTouchUpInside];
    [cell.mainVideoButton addTarget:self action:@selector(cellMainVideoOperation:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

#pragma mark - 从hex值中取颜色
-  (UIColor *)colorWithHexString:(NSString *)color alpha:(CGFloat)alpha
{
    //删除字符串中的空格
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6)
    {
        return [UIColor clearColor];
    }
    // strip 0X if it appears
    //如果是0x开头的，那么截取字符串，字符串从索引为2的位置开始，一直到末尾
    if ([cString hasPrefix:@"0X"])
    {
        cString = [cString substringFromIndex:2];
    }
    //如果是#开头的，那么截取字符串，字符串从索引为1的位置开始，一直到末尾
    if ([cString hasPrefix:@"#"])
    {
        cString = [cString substringFromIndex:1];
    }
    if ([cString length] != 6)
    {
        return [UIColor clearColor];
    }
     
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
     
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float)r / 255.0f) green:((float)g / 255.0f) blue:((float)b / 255.0f) alpha:alpha];
}


// 点击cell回调
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
//    if(_isScreenShare)
//    {
//        [HUDUtil hudShow:@"正在观看屏幕共享,无法点击" delay:2 animated:YES];
//        return;
//    }
//
//
//    MyCell *cell =(MyCell*)[_VideoListView cellForItemAtIndexPath:indexPath];
//
//    if(cell == _CurSelectCell && cell.isHightLight)
//    {
//
//        cell.isHightLight = NO;
//        cell.layer.borderWidth = 1.0;
//        cell.layer.borderColor = [UIColor whiteColor].CGColor;
//
//
//        UsrVideoId *OldInfo = _cusCameraView.usrVideoId;
//
//
//        UsrVideoId *NewInfo = _members[indexPath.item];
//
//        [self.cusCameraView setUsrVideoId:NewInfo];
//
//        [_members removeObject:NewInfo];
//
//        if(OldInfo)
//            [_members addObject:OldInfo];
//
//        [collectionView reloadData];
//
//    }else{
//
//        _CurSelectCell.isHightLight = NO;
//        _CurSelectCell.layer.borderWidth = 1.0;
//        _CurSelectCell.layer.borderColor = [UIColor whiteColor].CGColor;
//
//        cell.isHightLight = YES;
//        cell.layer.borderWidth = 1.0;
//        cell.layer.borderColor = [UIColor blueColor].CGColor;
//
//        _CurSelectCell = cell;
//
//    }
    
}

// 切换主视频
-(void)ChangeMainVideo:(NSString *)MainUserID
{
    
}



#pragma mark - scrollview Delegate

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if(_MainScrollView == scrollView)
    {
        int index = scrollView.contentOffset.x / scrollView.frame.size.width;
           _PageControl.currentPage = index;
           // ZY修改，在页数>=1时都要隐藏
                 if(_PageControl.currentPage >= 1)
                 {
                    [_TopView setHidden:YES];
                     [_InfoView setHidden:YES];
                    [_EndButton setTitle:@"" forState:UIControlStateNormal];
                     _StateBarIsHidden = true;
                    [_PageControl setFrame:CGRectMake(0, _Screen_height - 20, _Screen_width, 20)];
                 }
                 else
                 {
                     if(!_isLandScape)
                     {
                         [_TopView setHidden:NO];
                         [_InfoView setHidden:NO];
                                              
                         [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
                                         
                         _StateBarIsHidden = false;
                     }
                      else
                      {
                          [_TopView setHidden:YES];
                          [_InfoView setHidden:YES];
                          [_EndButton setTitle:@"" forState:UIControlStateNormal];
                          _StateBarIsHidden = true;
                      }

                       [_PageControl setFrame:CGRectMake(0, _Screen_height - 80, _Screen_width, 20)];
                
                 }
           [self setNeedsStatusBarAppearanceUpdate];
    }
    else
    {
        // ZY修改，处理在collectionView中的滑动事件
        int index = ceil(scrollView.contentOffset.x / scrollView.frame.size.width);
        _PageControl.currentPage = index + 1;
       NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
       if(_isLandScape)
       {
           for (MyCell *cell in arr) {

                [cell.titleLabel setFrame:CGRectMake(1, 1, _Screen_height*0.15,_Screen_width*0.07)];
                [cell.VideoView setFrame:CGRectMake(10, 10, _Screen_height/2-20,_Screen_width/2-20)];
                [cell.bottomView setFrame:CGRectMake(1, _Screen_width/2 - 40, _Screen_height/2-2,40)];
                [cell.micButton setFrame:CGRectMake(0,cell.bottomView.frame.size.height - 40 ,cell.bottomView.frame.size.width/4, 40)];
                [cell.cameraButton setFrame:CGRectMake(cell.bottomView.frame.size.width/4,cell.bottomView.frame.size.height - 40, cell.bottomView.frame.size.width/4, 40)];
                [cell.mainVideoButton setFrame:CGRectMake(cell.bottomView.frame.size.width/2,cell.bottomView.frame.size.height - 40 , cell.bottomView.frame.size.width/2, 40)];
                            
            }
       }
        else
        {
                 for (MyCell *cell in arr) {

                  [cell.titleLabel setFrame:CGRectMake(1, 1, _Screen_width*0.2,_Screen_height*0.05)];
                  [cell.VideoView setFrame:CGRectMake(10, 10, _Screen_width/2-20,_Screen_height/2-20)];
                  [cell.bottomView setFrame:CGRectMake(1, _Screen_height/2 - 40, _Screen_width/2-2,40)];
                  [cell.micButton setFrame:CGRectMake(0,cell.bottomView.frame.size.height - 40 ,cell.bottomView.frame.size.width/4, 40)];
                  [cell.cameraButton setFrame:CGRectMake(cell.bottomView.frame.size.width/4,cell.bottomView.frame.size.height - 40, cell.bottomView.frame.size.width/4, 40)];
                  [cell.mainVideoButton setFrame:CGRectMake(cell.bottomView.frame.size.width/2,cell.bottomView.frame.size.height - 40 , cell.bottomView.frame.size.width/2, 40)];
              }
        }
    }
   
}




#pragma mark -  退出按钮
- (void)_handleExit {
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"离开房间?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}];
    UIAlertAction *done = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeeting];
    }];
    [alertVC addAction:cancel];
    [alertVC addAction:done];
    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertVC.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertVC animated:YES completion:nil];
}

/* 跳转到上一界面 */
- (void)_jumpToPMeeting {
    
    if(_isCreatingMeeting)
    {
           if(self.lRoomIDBlock && _createMeetInfo.ID > 0)
           {
               self.lRoomIDBlock(_createMeetInfo.ID);
           }
    }
    else
    {
           if(self.lRoomIDBlock && _meetInfo.ID > 0)
           {
               self.lRoomIDBlock(_meetInfo.ID);
           }
    }
    // 离开房间
    [[CloudroomVideoMeeting shareInstance] exitMeeting];
    // 注销
    [[CloudroomVideoMgr shareInstance] logout];
    
    
   
    _isCreatingMeeting = false;
    
    
    // 退出界面
    [self dismissViewControllerAnimated:YES completion:nil];
    
    _isDismiss = YES;
    
    [_cusCameraView setUsrVideoId:nil];
    [_selfCameraView setUsrVideoId:nil];
    
    [_cusCameraView clearFrame];
    
    [_members removeAllObjects];
    [_VideoListView reloadData];
    
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];

    
    NSLog(@"------------ 退出播放器 --------------");
    
    
}

#pragma mark -  外放按钮
- (void)SoundBtAction{

    _SpeakerisClose = !_SpeakerisClose;
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    
    if(_SpeakerisClose){
        
        [cloudroomVideoMeeting setSpeakerMute:YES];
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_Off"] forState:UIControlStateNormal];
        
//        [HUDUtil hudShow:@"关闭扬声器" delay:2 animated:YES];
    }
    
    else{
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];
        [cloudroomVideoMeeting setSpeakerMute:NO];
        
//        [HUDUtil hudShow:@"开启扬声器" delay:2 animated:YES];

    }


}
#pragma mark -  麦克风按钮
- (void)MicrophoneBtAction{
    
    _MicisClose = !_MicisClose;
    
    if (_MicisClose) {
        
        [SDKUtil closeLocalMic];
        
//        [HUDUtil hudShow:@"关闭麦克风" delay:2 animated:YES];

        
    } else {
        [SDKUtil openLocalMic];
//        [HUDUtil hudShow:@"开启麦克风" delay:2 animated:YES];
    }
    
}

#pragma mark -  摄像头按钮
- (void)CameraBtAction{
    
    _CameraisClose = !_CameraisClose;
    
    if (_CameraisClose) {
        [SDKUtil closeLocalCamera];
        
        [_selfCameraView clearFrame];
        [_selfCameraView.placeImage setHidden:NO];
        
//        [HUDUtil hudShow:@"关闭摄像头" delay:2 animated:YES];
        
    } else {
        [SDKUtil openLocalCamera];
        [_selfCameraView.placeImage setHidden:YES];
        
//        [HUDUtil hudShow:@"开启摄像头" delay:2 animated:YES];
    }
    
}



-(void)MainVideoTapAction
{
    // 先取消一个3秒后的方法，保证不管点击多少次，都只有一个方法在3秒后执行
    [UIView cancelPreviousPerformRequestsWithTarget:self selector:@selector(dismissAction) object:nil];
    
    // 3秒后执行的方法
    [self performSelector:@selector(dismissAction) withObject:nil afterDelay:3];
    
    
    
    
    if(_TopView.frame.size.height>0)
    {
          [_TopView updateConstraints:^(MASConstraintMaker *make) {
           
            
            make.height.equalTo(@0);
          }];
        
    }else{
        
        
        [_TopView updateConstraints:^(MASConstraintMaker *make) {
            
            
            make.height.equalTo(@40);
        }];
            
    }
    
    
    if(_InfoView.frame.size.height>0)
    {
        [_InfoView updateConstraints:^(MASConstraintMaker *make) {
            
            
            make.height.equalTo(@0);
        }];
        
        [_EndButton setTitle:@"" forState:UIControlStateNormal];
    }else{
        [_InfoView updateConstraints:^(MASConstraintMaker *make) {
            
            
            make.height.equalTo(@64);
        }];
        
        [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
    }


    _StateBarIsHidden = !_StateBarIsHidden;
    
    [self setNeedsStatusBarAppearanceUpdate];
    
    
}

// 3秒后执行的方法
- (void)dismissAction
{
    
    [_TopView updateConstraints:^(MASConstraintMaker *make) {
        
        
        make.height.equalTo(@0);
    }];
    
    [_InfoView updateConstraints:^(MASConstraintMaker *make) {
        
        
        make.height.equalTo(@0);
    }];
    [_EndButton setTitle:@"" forState:UIControlStateNormal];
    
    
    _StateBarIsHidden = YES;
    [self setNeedsStatusBarAppearanceUpdate];
    
}


// 屏幕旋转
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
     [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];

    if(size.width > size.height)
    {
        _isLandScape = true;
        [self.MainScrollView setFrame:CGRectMake(0, 0, _Screen_height, _Screen_width)];
        [_MainScrollView setContentSize:CGSizeMake(2*_Screen_height, _Screen_width)];
          if(_PageControl.currentPage==0)
                    [_MainScrollView setContentOffset:CGPointMake(0, 0)];
                    else
                    [_MainScrollView setContentOffset:CGPointMake(_Screen_height, 0)];
         [_MainVideoView setFrame:CGRectMake(0, 0, _Screen_height, _Screen_width)];
        
        //横屏时隐藏顶部栏和底部栏
        _StateBarIsHidden = true;
        [_InfoView setHidden:YES];
        [_TopView setHidden:YES];
       [_selfCameraView setFrame:CGRectMake(_Screen_height - _Screen_width*0.25 - 44, 0, _Screen_width*0.25, _Screen_width*0.35)];
//        [_cusCameraView setFrame:CGRectMake(0, 10 + _Screen_width*0.15, _Screen_height, _Screen_width- (10 + _Screen_width*0.15))];
         [_cusCameraView setFrame:CGRectMake(0, 0, _Screen_height, _Screen_width)];
        [_shareView setFrame:CGRectMake(0, 10 + _Screen_width*0.15, _Screen_height, _Screen_width - (10 + _Screen_width*0.15))];
       
        
         [self.VideoListView setFrame:CGRectMake(_Screen_height, 0, _Screen_height, _Screen_width)];
        
//         [_InfoView setFrame:CGRectMake(0, 0, _Screen_height, 64)];
    
        
        [_EndButton setFrame:CGRectMake(_Screen_height*0.95 - 40, 20, 40, 40)];
        
        [_SoundButton setFrame:CGRectMake(_Screen_height*0.05, 20, 40, 40)];
        
        [_TitleLabel setFrame:CGRectMake(0, 20, _Screen_height, 40)];
        
        [_MicButton setFrame:CGRectMake(_Screen_height*0.15, 10, 40, 40)];
        
        [_CameraButton setFrame:CGRectMake(_Screen_height*0.85-40, 10, 40, 40)];
//             [_TopView setFrame:CGRectMake(0, _Screen_width-60, _Screen_height, 60)];
        
        //设置cell大小
              _Collectipnlayout.itemSize = CGSizeMake(_Screen_height/2,_Screen_width/2);
              
              NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
              
              for (MyCell *cell in arr) {

                  [cell.titleLabel setFrame:CGRectMake(1, 1, _Screen_height*0.15,_Screen_width*0.07)];
                  [cell.VideoView setFrame:CGRectMake(10, 10, _Screen_height/2-20,_Screen_width/2-20)];
                  [cell.bottomView setFrame:CGRectMake(1, _Screen_width/2 - 40, _Screen_height/2-2,40)];
                  [cell.micButton setFrame:CGRectMake(0,cell.bottomView.frame.size.height - 40 ,cell.bottomView.frame.size.width/4, 40)];
                  [cell.cameraButton setFrame:CGRectMake(cell.bottomView.frame.size.width/4,cell.bottomView.frame.size.height - 40, cell.bottomView.frame.size.width/4, 40)];
                  [cell.mainVideoButton setFrame:CGRectMake(cell.bottomView.frame.size.width/2,cell.bottomView.frame.size.height - 40 , cell.bottomView.frame.size.width/2, 40)];
                  
              }
        // ZY修改，设置为横向滑动适配
        [self.VideoListView setContentOffset:CGPointMake( _lastVideoCollectionViewOffsetYPortitNum*_Screen_height,0)];
    }
    else{
        _isLandScape = false;
        if(_PageControl.currentPage == 0)
        {
             _StateBarIsHidden = false;
            //横屏时不隐藏顶部栏和底部栏
            [_InfoView setHidden:NO];
            [_TopView setHidden:NO];
            [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
        }
        else
        {
             _StateBarIsHidden = true;
            [_InfoView setHidden:YES];
            [_TopView setHidden:YES];
        }
         [self.MainScrollView setFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];
         [_MainScrollView setContentSize:CGSizeMake(2*_Screen_width, _Screen_height)];
            if(_PageControl.currentPage==0)
            [_MainScrollView setContentOffset:CGPointMake(0, 0)];
            else
            [_MainScrollView setContentOffset:CGPointMake(_Screen_width, 0)];
        [_MainVideoView setFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];
        
         [_selfCameraView setFrame:CGRectMake(_Screen_width - _Screen_height*0.13, 74, _Screen_height*0.12, _Screen_height*0.15)];
        
        [_cusCameraView setFrame:CGRectMake(0, 64, _Screen_width, _Screen_height-80 - (64))];
//         [_cusCameraView setFrame:CGRectMake(0, 84 + _Screen_height*0.15, _Screen_width, _Screen_height-80 - (84 + _Screen_height*0.15))];
        
          [_shareView setFrame:CGRectMake(0, 84 + _Screen_height*0.15, _Screen_width, _Screen_height-80  - (84 + _Screen_height*0.15))];
        
        
         [self.VideoListView setFrame:CGRectMake(_Screen_width, 0, _Screen_width, _Screen_height)];
        
         [_InfoView setFrame:CGRectMake(0, 0, _Screen_width, 64)];
        [_EndButton setFrame:CGRectMake(_Screen_width*0.95 - 40, 20, 40, 40)];
        
        [_SoundButton setFrame:CGRectMake(_Screen_width*0.05, 20, 40, 40)];
        
         [_TitleLabel setFrame:CGRectMake(_Screen_width*0.05 + 40 , 20, _Screen_width*0.95 - 40 - (_Screen_width*0.05 + 40), 40)];
//         [_TitleLabel setFrame:CGRectMake(0, 20, _Screen_width, 40)];
        
        [_MicButton setFrame:CGRectMake(_Screen_width*0.15, 10, 40, 40)];
        
        [_CameraButton setFrame:CGRectMake(_Screen_width*0.85-40, 10, 40, 40)];
        
          [_TopView setFrame:CGRectMake(0, _Screen_height-60, _Screen_width, 60)];
        
        //设置cell大小
        _Collectipnlayout.itemSize = CGSizeMake(_Screen_width/2,_Screen_height/2);
        
        NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
        
        for (MyCell *cell in arr) {
            [cell.titleLabel setFrame:CGRectMake(1, 1, _Screen_width*0.2,_Screen_height*0.05)];
            [cell.VideoView setFrame:CGRectMake(10, 10, (_Screen_width/2)-20,(_Screen_height/2)-20)];
            [cell.bottomView setFrame:CGRectMake(1, _Screen_height/2 - 40, _Screen_width/2-2,40)];
            [cell.micButton setFrame:CGRectMake(0,cell.bottomView.frame.size.height - 40 ,cell.bottomView.frame.size.width/4, 40)];
            [cell.cameraButton setFrame:CGRectMake(cell.bottomView.frame.size.width/4,cell.bottomView.frame.size.height - 40, cell.bottomView.frame.size.width/4, 40)];
            [cell.mainVideoButton setFrame:CGRectMake(cell.bottomView.frame.size.width/2,cell.bottomView.frame.size.height - 40 , cell.bottomView.frame.size.width/2, 40)];
        }
       // ZY修改，设置为横向滑动适配
        [self.VideoListView setContentOffset:CGPointMake( _lastVideoCollectionViewOffsetYLandScapeNum*_Screen_width,0)];
    }
    [self setNeedsStatusBarAppearanceUpdate];
}


// 换页标示
-(void)dealPage:(UIPageControl *)pc
{
    //把序号转化为滚动视图x的偏移
    double x = _MainScrollView.frame.size.width * pc.currentPage;

    [_MainScrollView setContentOffset:CGPointMake(x, 0) animated:YES];
    
  
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
   if(scrollView == _MainScrollView)
   {
       if(!scrollView.isDecelerating && !scrollView.isDragging &&!scrollView.isTracking)
         {

             if(_PageControl.currentPage == 0)
             {
                 [_MainScrollView setContentOffset:CGPointMake(0, 0) animated:NO];
             }
             else
             {
                 if(_isLandScape)
                 {
                     [_MainScrollView setContentOffset:CGPointMake(_Screen_height, 0) animated:NO];
                 }
                 else
                 {
                     [_MainScrollView setContentOffset:CGPointMake(_Screen_width, 0) animated:NO];
                 }
             }
         }
   }
  
}

#pragma mark - 全面屏适配
-(void)viewSafeAreaInsetsDidChange
{
    [super viewSafeAreaInsetsDidChange];
    // 如果是刘海屏
    if([self isNotchScreen])
    {
         if(_isLandScape)
            {
                   [_cusCameraView setFrame:CGRectMake(0, 64, _Screen_height, _Screen_width-60-self.view.safeAreaInsets.bottom - (64))];
                   [_selfCameraView setFrame:CGRectMake(_Screen_height - _Screen_width*0.25 - 44, 0, _Screen_width*0.25, _Screen_width*0.35)];
        //         [_cusCameraView setFrame:CGRectMake(0, 84 + _Screen_width*0.15, _Screen_height, _Screen_width-60-self.view.safeAreaInsets.bottom - (84 + _Screen_width*0.15))];
                 [_PageControl setFrame:CGRectMake(0, _Screen_width - 20 - self.view.safeAreaInsets.bottom, _Screen_height, 20)];
                 [_TopView setFrame:CGRectMake(0, _Screen_width-60-self.view.safeAreaInsets.bottom, _Screen_height, 60+self.view.safeAreaInsets.bottom)];
                
                [self.VideoListView setFrame:CGRectMake(_Screen_height + 44, 0, _Screen_height - 44, _Screen_width-21)];
                [self.VideoListView setContentSize:CGSizeMake(_Screen_height - 88 , _Screen_width-21)];
                [_Collectipnlayout setItemSize:CGSizeMake((_Screen_height - 88)/2, (_Screen_width-21)/2)];
                
                NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
                
                for (MyCell *cell in arr) {

                    [cell.titleLabel setFrame:CGRectMake(1, 1, _Screen_height*0.15,_Screen_width*0.07)];
                    [cell.VideoView setFrame:CGRectMake(10, 10, _Screen_height/2-20,_Screen_width/2-20)];
                    [cell.bottomView setFrame:CGRectMake(1, (_Screen_width-21)/2 - 40, (_Screen_height - 88)/2-2,40)];
                    [cell.micButton setFrame:CGRectMake(0,cell.bottomView.frame.size.height - 40 ,cell.bottomView.frame.size.width/4, 40)];
                    [cell.cameraButton setFrame:CGRectMake(cell.bottomView.frame.size.width/4,cell.bottomView.frame.size.height - 40, cell.bottomView.frame.size.width/4, 40)];
                    [cell.mainVideoButton setFrame:CGRectMake(cell.bottomView.frame.size.width/2,cell.bottomView.frame.size.height - 40 , cell.bottomView.frame.size.width/2, 40)];
                    
                }
            }
            else
            {
                [_cusCameraView setFrame:CGRectMake(0, 84, _Screen_width, _Screen_height-80 - self.view.safeAreaInsets.bottom - (84))];
                [_selfCameraView setFrame:CGRectMake(_Screen_width - _Screen_height*0.13, 94, _Screen_height*0.12, _Screen_height*0.15)];
                [_EndButton setFrame:CGRectMake(_Screen_width*0.95 - 40, 44, 40, 40)];
                [self.VideoListView setFrame:CGRectMake(_Screen_width, 44, _Screen_width, _Screen_height-44-34)];
                [self.VideoListView setContentSize:CGSizeMake(_Screen_width, _Screen_height-44-34)];
                [_Collectipnlayout setItemSize:CGSizeMake(_Screen_width/2, (_Screen_height-44-34)/2)];
                // 设置cell大小
                NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
                
                for (MyCell *cell in arr) {
                    [cell.titleLabel setFrame:CGRectMake(1, 1, _Screen_width*0.2,_Screen_height*0.05)];
                    [cell.VideoView setFrame:CGRectMake(10, 10, (_Screen_width/2)-20,(_Screen_height/2)-20)];
                    [cell.bottomView setFrame:CGRectMake(1, (_Screen_height-44-34)/2 - 40, _Screen_width/2-2,40)];
                    [cell.micButton setFrame:CGRectMake(0,cell.bottomView.frame.size.height - 40 ,cell.bottomView.frame.size.width/4, 40)];
                    [cell.cameraButton setFrame:CGRectMake(cell.bottomView.frame.size.width/4,cell.bottomView.frame.size.height - 40, cell.bottomView.frame.size.width/4, 40)];
                    [cell.mainVideoButton setFrame:CGRectMake(cell.bottomView.frame.size.width/2,cell.bottomView.frame.size.height - 40 , cell.bottomView.frame.size.width/2, 40)];
                }
                
                
                [_SoundButton setFrame:CGRectMake(_Screen_width*0.05, 44, 40, 40)];
//                 [_TitleLabel setFrame:CGRectMake(0, 44, _Screen_width, 40)];
                [_TitleLabel setFrame:CGRectMake(_Screen_width*0.05 + 40 , 44, _Screen_width*0.95 - 40 - (_Screen_width*0.05 + 40), 40)];
                [_InfoView setFrame:CGRectMake(0, 0, _Screen_width, 84)];
        //        [_cusCameraView setFrame:CGRectMake(0, 84 + _Screen_height*0.15, _Screen_width, _Screen_height-80 - self.view.safeAreaInsets.bottom - (84 + _Screen_height*0.15))];
                    [_PageControl setFrame:CGRectMake(0, _Screen_height - 80 - self.view.safeAreaInsets.bottom, _Screen_width, 20)];
                    [_TopView setFrame:CGRectMake(0, _Screen_height-60-self.view.safeAreaInsets.bottom, _Screen_width, 60+self.view.safeAreaInsets.bottom)];
            }
    }
}

#pragma mark - 控制他人的麦克风
- (void)cellMicOperation:(UIButton *)sender
{
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    CGPoint point = sender.center;
    point = [self.VideoListView convertPoint:point fromView:sender.superview];
    NSIndexPath* indexpath = [self.VideoListView indexPathForItemAtPoint:point];
    UsrVideoId *userInfo = _members[indexpath.item];
    AUDIO_STATUS status = [cloudroomVideoMeeting getAudioStatus:userInfo.userId];
           
    if(status == ACLOSE)
    {
        [cloudroomVideoMeeting openMic:userInfo.userId];
        NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 调整用户%@的麦克风为开",userInfo.userId);

    }
    else if(status == AOPEN)
    {
       [cloudroomVideoMeeting closeMic:userInfo.userId];
       NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 调整用户%@的麦克风为关",userInfo.userId);
                
    }
     [UIView performWithoutAnimation:^{
         //刷新界面
         [self.VideoListView reloadData];
       }];
        
}

#pragma mark - 控制他人的摄像头
- (void)cellCamOperation:(UIButton *)sender
{
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    CGPoint point = sender.center;
    point = [self.VideoListView convertPoint:point fromView:sender.superview];
    NSIndexPath* indexpath = [self.VideoListView indexPathForItemAtPoint:point];
    UsrVideoId *userInfo = _members[indexpath.item];
    // 如果是控制自己的
    if([userInfo.userId isEqualToString:[cloudroomVideoMeeting getMyUserID]])
    {
        _CameraisClose = !_CameraisClose;
        if (_CameraisClose) {
            NSLog(@">>>>>>>>>>>>>>>>>>>>>>>> 控制自己摄像头关闭");
            [SDKUtil closeLocalCamera];
            [_selfCameraView clearFrame];
            [_selfCameraView.placeImage setHidden:NO];
            
        } else {
             NSLog(@">>>>>>>>>>>>>>>>>>>>>>>> 控制自己摄像头开启");
            [SDKUtil openLocalCamera];
            [_selfCameraView.placeImage setHidden:YES];
        }
    }
    // 如果控制他人的
    else
    {
        NSString *message=[NSString stringWithFormat:@"MedCareMessage_{\"Type\":\"Compere\",\"InstructType\":\"SwitchVideo\",\"XMPMainVideo\":\"%@.%hd\"}",userInfo.userId,userInfo.videoID];
        [cloudroomVideoMeeting sendIMmsg:message toUserID:userInfo.userId];
         NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 向%@发送开关摄像头的消息",userInfo.userId);
    }
}

#pragma mark - 将他人设置为主视频
- (void)cellMainVideoOperation:(UIButton *)sender
{
    if(![sender.titleLabel.text isEqualToString:@"焦点视频"])
    {
        CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
        CGPoint point = sender.center;
        point = [self.VideoListView convertPoint:point fromView:sender.superview];
        NSIndexPath* indexpath = [self.VideoListView indexPathForItemAtPoint:point];
        UsrVideoId *userInfo = _members[indexpath.item];
        
        [cloudroomVideoMeeting setDefaultVideo:userInfo.userId videoID:userInfo.videoID];
        [cloudroomVideoMeeting setMainVideo:userInfo.userId];
        NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 调整用户%@为焦点视频",userInfo.userId);
    }
}


#pragma mark - 监听收到云屋IM消息
// MedCareMessage_{"Type":"Compere","InstructType":"SwitchVideo","XMPMainVideo":"zz1@ics1.sino-med.net.2"}xxs
- (void)notifyIMmsg:(NSString *)romUserID text:(NSString *)text sendTime:(int)sendTime
{
    
    text = [text substringWithRange:NSMakeRange(15, text.length - 15)];
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>> 收到%@发送的云屋IM消息为：%@",romUserID,text);

    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSMutableDictionary *contentDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    
    if([contentDic[@"InstructType"]  isEqual: @"SwitchVideo"] && [contentDic[@"Type"]  isEqual: @"Compere"])
    {
             NSString *videoInfo = contentDic[@"XMPMainVideo"];
        
             NSString *myUserID = [[CloudroomVideoMeeting shareInstance] getMyUserID];
            
             short videoId = [[CloudroomVideoMeeting shareInstance] getDefaultVideo:myUserID];
        
             NSString *userJID =[myUserID stringByAppendingString:[NSString stringWithFormat:@".%d",videoId]];
            
             NSLog(@"======================>XMPMainVideo:%@  ----  myUserID:%@",videoInfo,userJID);
            // 是自己的
            if([videoInfo isEqualToString:userJID])
            {
                _CameraisClose = !_CameraisClose;
                    
                    if (_CameraisClose) {
                        [SDKUtil closeLocalCamera];
                        
                        [_selfCameraView clearFrame];
                        [_selfCameraView.placeImage setHidden:NO];
                        
                        [HUDUtil hudShow:@"主持人已关闭您的摄像头" delay:2 animated:YES];
                        
                    } else {
                        
                        UIAlertController *ac =[UIAlertController alertControllerWithTitle:@"提示" message:@"主持人请求开启您的摄像头" preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"是" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                             [SDKUtil openLocalCamera];
                             [_selfCameraView.placeImage setHidden:YES];
                             [HUDUtil hudShow:@"主持人已开启您的摄像头" delay:2 animated:YES];
                        }];
                        [ac addAction:okAction];
                        
                        UIAlertAction *noAction = [UIAlertAction actionWithTitle:@"否" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                            _CameraisClose = true;
                        }];
                        [ac addAction:noAction];
                        [self presentViewController:ac animated:YES completion:nil];
                       
                    }
            }
   
    }
    else if([contentDic[@"InstructType"]  isEqual: @"SetSpeakerUserInfo"] && [contentDic[@"Type"]  isEqual: @"Compere"])
    {
        if([contentDic[@"SpeakerUserID"] isEqualToString:@""] && [contentDic[@"SpeakerVideoID"] isEqualToString:@"0"])
        {
            NSString *usrID = [[CloudroomVideoMeeting shareInstance]getMyUserID];
            short videoID = [[CloudroomVideoMeeting shareInstance]getDefaultVideo:usrID];
            UsrVideoId *selfVideo  = [[UsrVideoId alloc]init];
            selfVideo.userId = usrID;
            selfVideo.videoID = videoID;
            [_selfCameraView clearFrame];
            [_selfCameraView setUsrVideoId:selfVideo];
        }
        else
        {
            UsrVideoId *hostVideo = [[UsrVideoId alloc]init];
            hostVideo.userId = contentDic[@"SpeakerUserID"];
            hostVideo.videoID = [contentDic[@"SpeakerVideoID"] intValue];
            [_selfCameraView clearFrame];
            [_selfCameraView setUsrVideoId:hostVideo];
        }
    }
}

- (void)microphoneAction:(BOOL) isMicOn{
    
    _MicisClose = !isMicOn;
    // 打开本地麦克风
    if(_MicisClose)
    {
        [SDKUtil closeLocalMic];
    }
    else
    {
        [SDKUtil openLocalMic];
    }
    
}

- (void)cameraAction:(BOOL) isCameraOn
{
    _CameraisClose = !isCameraOn;
    // 打开本地摄像头
    if(_CameraisClose)
      {
          [SDKUtil closeLocalCamera];
      }
      else
      {
          [SDKUtil openLocalCamera];
      }
}

- (void)joinRoomSuccessBlock:(JoinRoomIDBlock)block
{
    self.roomIDBlock = block;
}

- (void)leaveRoomBlock:(LeaveRoomIDBlock)block
{
    self.lRoomIDBlock = block;
}

- (BOOL)isNotchScreen {
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        return NO;
    }
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    NSInteger notchValue = size.width / size.height * 100;
    
    if (216 == notchValue || 46 == notchValue) {
        return YES;
    }
    
    return NO;
}

@end
