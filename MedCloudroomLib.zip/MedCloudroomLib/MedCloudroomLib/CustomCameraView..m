//
//  MTwoTwoView.m
//  Meeting
//
//  Created by king on 2018/6/28.
//  Copyright © 2018年 BossKing10086. All rights reserved.
//

#import "CustomCameraView.h"
#import "Masonry.h"

#define UIColorFromRGBA(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:a]

@interface CustomCameraView()

@end

@implementation CustomCameraView
#pragma mark - lazying

//-(UILabel*)remindLabel
//{
//    if(_remindLabel == nil)
//    {
//        _remindLabel = [[UILabel alloc]init];
//        _remindLabel.textAlignment = NSTextAlignmentCenter;
//        _remindLabel.textColor = [UIColor whiteColor];
//        [_remindLabel setFont:[UIFont systemFontOfSize:16]];
//        [_remindLabel setHidden: YES];
//    }
//    return _remindLabel;
//}

-(UIImageView *)placeImage
{
    if(_placeImage == nil)
    {
        _placeImage = [[UIImageView alloc]init];
        _placeImage.image = [UIImage imageNamed:@"meeting_place_holder"];
    }
    return _placeImage;
}

-(UILabel *)titleLabel
{
    if(_titleLabel == nil)
    {
        _titleLabel = [[UILabel alloc]init];
//        _titleLabel.layer.cornerRadius = 6;
//        _titleLabel.layer.masksToBounds = YES;
        _titleLabel.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.3);
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.textColor = [UIColor whiteColor];
        [_titleLabel setFont:[UIFont systemFontOfSize:12]];
        [_titleLabel setHidden:YES];
        
    }
    return _titleLabel;
}

#pragma mark - init
-(instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self setupUI];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
}
-(void)setupUI
{
    [self setBackgroundColor:[UIColor blackColor]];//UIColorFromRGBA(31, 47, 65, 1.0)];
    [self addSubview:self.placeImage];
    [self addSubview:self.titleLabel];
//    [self addSubview:self.remindLabel];
    
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(4);
        make.top.equalTo(self).offset(2);
//        make.bottom.equalTo(self).offset(2);
    }];
    
    [self.placeImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.centerX.equalTo(self);
        make.width.mas_equalTo(65);
        make.height.mas_equalTo(65);
    }];
    [_placeImage setContentMode:UIViewContentModeScaleAspectFit];
    
//    [self.remindLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.equalTo(self);
//        make.centerX.equalTo(self);
//        make.width.mas_equalTo(300);  
//        make.height.mas_equalTo(150);
//    }];
}

//#pragma mark - override
- (void)setUsrVideoId:(UsrVideoId *)usrVideoId {
    [super setUsrVideoId:usrVideoId];

    BOOL value = usrVideoId ? YES : NO;
    _placeImage.hidden = value;
//    _remindLabel.hidden = value;
//    _titleLabel.text = usrVideoId.userId;
    
    if (!value) {
        [self clearFrame];
        [self setBackgroundColor:[UIColor blackColor]];//UIColorFromRGBA(31, 47, 65, 1.0)];
    }
}
@end
