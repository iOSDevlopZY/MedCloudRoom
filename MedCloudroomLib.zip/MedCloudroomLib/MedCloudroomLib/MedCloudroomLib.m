//
//  MedCloudroomLib.m
//  MedCloudroomLib
//
//  Created by pg on 2019/11/9.
//  Copyright © 2019年 美迪康yh. All rights reserved.
//

#import "MedCloudroomLib.h"
//#import "CloudroomVideoSDK_IOS.h"
#import <CloudroomVideoSDK_IOS/CloudroomVideoSDK_IOS.h>


@implementation MedCloudroomLib


-(void)InitCloudroomSDK
{
    if([[CloudroomVideoSDK shareInstance] isInitSuccess])
    {
        [[CloudroomVideoSDK shareInstance] uninit];
    }
    
    
    SdkInitDat *sdkInitData = [[SdkInitDat alloc] init];
    [sdkInitData setShowSDKLogConsole:NO];
    
    [sdkInitData setNoCall:NO];
    [sdkInitData setNoQueue:YES];
    [sdkInitData setNoMediaDatToSvr:NO];
    [sdkInitData setIsMultiDelegate:YES];
    CRVIDEOSDK_ERR_DEF error = [[CloudroomVideoSDK shareInstance] initSDK:sdkInitData];
    
    if (error != CRVIDEOSDK_NOERR) {
        NSLog(@"CloudroomVideoSDK init error!");
        [[CloudroomVideoSDK shareInstance] uninit];
    }
    
    NSLog(@"GetCloudroomVideoSDKVer:%@", [CloudroomVideoSDK getCloudroomVideoSDKVer]);

}


-(void)DeInitCloudSDK
{
    [[CloudroomVideoSDK shareInstance] uninit];
}

@end
