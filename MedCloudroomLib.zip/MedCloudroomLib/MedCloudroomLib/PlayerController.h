//
//  PlayerController.h
//  MedCloudroomLib
//
//  Created by pg on 2019/11/11.
//  Copyright © 2019年 美迪康yh. All rights reserved.
//

#import <UIKit/UIKit.h>
// ZY修改，添加房间号回调block
typedef void (^ReturnRoomIDBlock)(int roomID);
typedef void (^JoinRoomIDBlock)(int roomID);
typedef void (^LeaveRoomIDBlock)(int roomID);

@interface PlayerController : UIViewController

@property(nonatomic,assign)BOOL isDismiss;

@property(nonatomic,assign)int backGroundSize;
@property(nonatomic,strong) NSString *backGroundTitle;
@property(nonatomic,strong) NSString *holderJID;
@property(nonatomic,strong) NSString *currentJoinRefreshJID;
@property(nonatomic,strong) NSString *currentLeaveRefreshJID;

@property (nonatomic,copy) ReturnRoomIDBlock callbackBlock;
@property (nonatomic,copy) JoinRoomIDBlock roomIDBlock;
@property (nonatomic,copy) LeaveRoomIDBlock lRoomIDBlock;

-(void)StartCloudRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo isMicOn:(BOOL)micOn isCameraOn:(BOOL)cameraOn isSelfCreatingRoom:(NSString *)isSelfCreateRoom;

//// ZY修改，创建房间
-(void)CreateCloudRoomWithUserID:(NSString *)userID NickName:(NSString *)nickName withReturnRoomID:(ReturnRoomIDBlock)block isMicOn:(BOOL)micOn isCameraOn:(BOOL)cameraOn;

/*麦克风事件*/
- (void)microphoneAction:(BOOL) isMicOn;

/*摄像头事件*/
- (void)cameraAction:(BOOL) isCameraOn;

/*加入房间*/
- (void)joinRoomSuccessBlock:(JoinRoomIDBlock)block;

/*离开房间**/
- (void)leaveRoomBlock:(LeaveRoomIDBlock)block;
@end
